package com.ims.lib;

import com.sun.org.apache.xml.internal.security.exceptions.Base64DecodingException;
import com.sun.org.apache.xml.internal.security.utils.Base64;

public class PasswordEncryption {
	public static void main(String args[]) throws Base64DecodingException{
		String a = "System$123";
		String encodedBytes = Base64.encode(a.getBytes());
		System.out.println("encodedBytes "+ new String(encodedBytes));

		byte[] decodedBytes = Base64.decode(encodedBytes);
		System.out.println("decodedBytes "+ new String(decodedBytes));

	}

}
