package com.ims.lib;

public class ObjectDefinitionLibrary {
	public String UserName = "//*[@id='username']";
	public String Password = "//*[@id='password']";
	public String Login_Button = "//*[@id='submit']";
	public String SearchMedicine = "//*[@id='query']";
	public String DisplayingApp = "//*[@id='search']/div/div/div[2]/div/div/div/div/div[1]/div[2]/div/div[1]/div";
	public String ScoreApp = "//*[@id='search']/div/div/div[2]/div/div/div/div/div[1]/div[2]/div/div[2]/div/div[2]/div/span[2]";
	public String DisplayedAppScore = "//*[@id='summary']/div/div/div/div[2]/div[3]/div/span";
	public String DescriptionTab = "//*[@id='nav']/ul/li[1]/a";
	public String GallaryTab = "//*[@id='nav']/ul/li[2]/a";
	public String RatingsTab = "//*[@id='nav']/ul/li[3]/a";
	public String ScoreTab = "//*[@id='nav']/ul/li[4]/a";
	public String RateItButton = "//button[contains(@class,'rate-it')]";
	public String StarRating = "//*[@id='reviewForm']/div[1]/label";
	public String RatingStar="//*[@id='review-rating']/img";
	public String ReviewTextArea = "//*[@id='review-text']";
	public String submitReviewButton = "//*[@id='reviewForm']/div[3]/button[2]";
	public String successMessage = "//*[@id='errorContainer']/p";
}
