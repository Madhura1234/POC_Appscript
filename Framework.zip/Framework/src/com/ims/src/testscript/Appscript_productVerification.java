package com.ims.src.testscript;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class Appscript_productVerification {
	static ExtentReports report;
	static ExtentTest logger;
public static void main(String args[]){
	try
	{
		
	}
	catch(Exception e){
		report = new ExtentReports(System.getProperty("user.dir") + "/Reports/Extentreport.html");
		logger = report.startTest("Validating a product in AppScript application");
	}
}
}
