package com.ims.src.testscript;

import java.io.IOException;
import java.sql.SQLException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.ims.lib.UtilLib;
import com.ims.lib.ApplicationUtility;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;



public class Sample {
	private static WebDriver driver;
	
	ExtentReports report  = new ExtentReports(System.getProperty("user.dir")+ "/Reports/Extentreport.html",true);
	ExtentTest logger = report.startTest("Validating an app in AppScript application");
	@BeforeClass
	public void initiatebrowser() throws Exception{
		ApplicationUtility.AppScript_Login();
	}

	@Test
	public void appscriptValidation(){
		ApplicationUtility.AppscriptValidation(report, logger);
	}


	@AfterClass
	public void tearDown() throws Exception{
		report.flush();
	}

}
