package ims.appscript;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import com.ims.lib.ApplicationUtility;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class Appscript_AppValidation {
	private static WebDriver driver;

	ExtentReports report  = new ExtentReports(System.getProperty("user.dir")+ "/Reports/Extentreport.html",true);
	ExtentTest logger = report.startTest("Validating an app in AppScript application");

	@Test
	public void initiatebrowser() throws Exception{
		ApplicationUtility.DriverScripts(report,logger);
		report.endTest(logger);
	}


	@AfterClass
	public void tearDown() throws Exception{
		report.flush();
	}
}
