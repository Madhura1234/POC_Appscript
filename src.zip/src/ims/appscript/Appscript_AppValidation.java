package ims.appscript;

import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.monte.screenrecorder.ScreenRecorder;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.ims.lib.ApplicationUtility;
import com.ims.lib.TriggerMail;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class Appscript_AppValidation {
	

 String currentTime = systemTimeStamp(); // Build dd.mm.yy..- hour.. minute.. second value. 
	
 public static String systemTimeStamp() {
		DateFormat df = new SimpleDateFormat("dd.MMM.yyyy-HH.mm.ss");
		Date today = Calendar.getInstance().getTime();
		String runTime = df.format(today);
		//System.out.println(df.format(today));
		return runTime;
	}
 
 
 String Finalreportpath=System.getProperty("user.dir")+ "/Reports/Automation_" + currentTime + "Extentreport.html";
	
	ExtentReports report  = new ExtentReports(Finalreportpath,true);
	ExtentTest logger;


	private ScreenRecorder screenRecorder;
	
	
@BeforeClass
	public  void Reportconfiguraition(){
		report.config().documentTitle("AppScript Automation Summary Report");
		report.config().reportHeadline("AppScript Search Apps Report");
		
	//	report.config().reportName("Appscript Automation Extent Reports");
		//String currentDate = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
		//String reportPath =System.getProperty("user.dir")+"/Reports/"+ currentDate + ".html";
		//System.out.println(reportPath);
		 //report  = new ExtentReports(reportPath, true);
	}

	@Test
	public void SearchAppsinAppscript() throws Exception{
	   ApplicationUtility.DriverScripts(report,logger);
	}
	
	/*@Test
	public void SearchAppsinAppscript2() throws Exception{
	   ApplicationUtility.DriverScripts(report,logger);
	}*/


	@AfterClass
	public void tearDown() throws Exception{
	report.flush();
	 TriggerMail tm = new TriggerMail();
		tm.Email_Authentication(Finalreportpath);
	
	}
	
	
	
/*	@BeforeSuite
    public void startRecording() throws Exception {    

      GraphicsConfiguration gc = GraphicsEnvironment
               .getLocalGraphicsEnvironment()
               .getDefaultScreenDevice()
               .getDefaultConfiguration();
      
      
     /* 
      
      this.screenRecorder = new ScreenRecorder(gc,
              new Format(MediaTypeKey, MediaType.FILE, MimeTypeKey, MIME_AVI),
              new Format(MediaTypeKey, MediaType.VIDEO, EncodingKey, ENCODING_AVI_TECHSMITH_SCREEN_CAPTURE,
                   CompressorNameKey, ENCODING_AVI_TECHSMITH_SCREEN_CAPTURE,
                   DepthKey, 24, FrameRateKey, Rational.valueOf(15),
                   QualityKey, 1.0f,
                   KeyFrameIntervalKey, 15 * 60),
              new Format(MediaTypeKey, MediaType.VIDEO, EncodingKey, "black",
                   FrameRateKey, Rational.valueOf(30)),
              null);
       
     //  gc.
       
       
      // VideoReord  videoReord = new VideoReord();

       //    this.screenRecorder = new ScreenRecorder(gc);
  // this.screenRecorder.start();

}

@AfterSuite
public void stopRecording() throws Exception {
  //this.screenRecorder.stop();
  
}*/
	
	
	
}
