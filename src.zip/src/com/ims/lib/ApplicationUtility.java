package com.ims.lib;

import java.io.IOException;
import java.text.AttributedCharacterIterator.Attribute;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.codec.binary.Base64;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;



public class ApplicationUtility {
	private static WebDriver driver;
	static String xlFilePath;
	public static ObjectDefinitionLibrary element = new ObjectDefinitionLibrary();
	public static ApplicationUtility pom = new ApplicationUtility(driver);
	public static ExcelApiTest test = new ExcelApiTest();
	public static UtilLib util = new UtilLib();
	static ExtentReports report;
	static ExtentTest logger;
	static String screenshot;

	@SuppressWarnings("static-access")
	public ApplicationUtility(WebDriver driver) {
		super();
		this.driver = driver;
	}


	/********************************************************************************************
	 * @Function_Name : DriverScript
	 * @Description :  Login for Appscript application
	 * @author : Madhura	
	 * @return boolean
	 ********************************************************************************************/
	public static boolean DriverScripts(ExtentReports report,ExtentTest logger) throws IOException, InterruptedException  {
		try {
			String xlFilePath=System.getProperty("user.dir")+"/TestData.xlsx";
			String sheet="Appscript";
			int rowcountvalue = test.getRowCount(xlFilePath, sheet);
			String Failredcol="Red";
			System.out.println(rowcountvalue);
			for(int i=1; i<=rowcountvalue; i++){

			//	driver = UtilLib.getDriver();
			//	driver.manage().window().maximize();
				// driver.manage().deleteAllCookies();

				String Falgexecution = test.getCellData(xlFilePath, sheet,"ExecutionFlag", i);  // Test case flag execution. 
			//	report.config().
				
				if(Falgexecution.equalsIgnoreCase("Y")){
					String URL = test.getCellData(xlFilePath, sheet,"URL", i);
					String un = test.getCellData(xlFilePath, sheet,"UserName", i);
					String pw = test.getCellData(xlFilePath, sheet, "Password", i);
				//	driver = UtilLib.getDriver();

			      		logger = report.startTest("The URL picked up for execution is"+URL);  // Environment details has to provide. 
					

			      
			      		driver = UtilLib.getDriver();
			    		driver.manage().window().maximize();
			    	    driver.manage().deleteAllCookies();
			    	    driver.get(URL);
						
					//driver.get(URL);
					System.out.println(URL);
					
					WebDriverWait wait = new WebDriverWait(driver,60);
					
		//		Wait<F>	
					
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element.UserName)));
					//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element.SearchMedicine)));
					logger.log(LogStatus.INFO,"Appscript URL executed is:<b>"+URL+"</b>");
					
					String screenshot = util.screenshot(driver, "Login into Appscript application with valid credentials for the URL");
				//	logger.log(LogStatus.PASS, "Login into Appscript application" + logger.addScreenCapture(screenshot));
					String actualTitle = driver.getTitle();
					String expectedTitle = "AppScript Prescriber | Consumer Store";
				
					if (expectedTitle.contains(actualTitle)){
						logger.log(LogStatus.PASS, "The title is displayed on the web page:<b> "+driver.getTitle()+"</b>" );
					}       else{
						logger.log(LogStatus.FAIL, "An title is displayed on the web page: <b>"+driver.getTitle()+"</b>");
						//Assert.assertTrue(false);
					}
				
					
								
					
					driver.findElement(By.xpath(element.UserName)).clear();
					driver.findElement(By.xpath(element.UserName)).sendKeys(un);
					driver.findElement(By.xpath(element.Password)).clear(); 
				//	System.out.println(pw);
					
					byte[] decodedBytes = Base64.decodeBase64(pw);
					
					System.out.println(new String(decodedBytes));
			 				
					driver.findElement(By.xpath(element.Password)).sendKeys(new String(decodedBytes));

					
					String col = "BLUE";

						
					
					driver.findElement(By.xpath(element.Login_Button)).click();


					String AppValueSearch = test.getCellData(xlFilePath, sheet,"App Value", i);
					
				try {
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element.SearchMedicine)));
				}
				
				catch(Exception ex){
					
					ex.printStackTrace();
					ex.getMessage();
					logger.log(LogStatus.FAIL, " Unable to Login for User <b>"+ un + "and its URL " + URL +"</b>" + logger.addScreenCapture(screenshot));
					report.endTest(logger);
				//	ex.
					driver.close();
					 driver.quit();
					 
				try{
					 int a =0;
				    //  int b = 1/a;
				}
				 catch (Exception ex1){
					 
				 }

		         Reporter.getCurrentTestResult().setStatus(ITestResult.FAILURE);
	    			continue;
					
				}
				
					WebElement SearchMedicine = driver.findElement(By.xpath(element.SearchMedicine));
					SearchMedicine.sendKeys(AppValueSearch);
			
				
					

					List<WebElement> autoPopulatedList=driver.findElements(By.xpath("//*[@id='search-form']/div/span/span"));  
					for(WebElement ele:autoPopulatedList)  
					{  
						System.out.println(ele.getText());
						logger.log(LogStatus.INFO, "The autopopulated values in search box of Appscript application is: <b>"+ele.getText()+"</b>");
					}

					screenshot = util.screenshot(driver, "Search a product in Appscript Application");
					logger.log(LogStatus.PASS, "Search a product in Appscript Application" + logger.addScreenCapture(screenshot));
					//System.out.println(SearchMedicine.getAttribute("value"));
					logger.log(LogStatus.PASS, "The searched product in dashboard page of Appscript application is: <b>"+SearchMedicine.getAttribute("value")+"</b>");
					driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
					SearchMedicine.sendKeys(Keys.ENTER);


					//Verify the product name in the dashboard page
					
					try{
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element.DisplayingApp)));
						String DisplayingRecords = driver.findElement(By.xpath(element.DisplayingApp)).getText();
						logger.log(LogStatus.PASS,"<marquee><font color="+"\""+col+"\">Displayed record of product name in dashboard page of Appscript application is: "+DisplayingRecords+"</marquee>");
						System.out.println("displaying record is:"+DisplayingRecords);
					}
					catch(Exception ex){
						ex.printStackTrace();
						ex.getMessage();
						logger.log(LogStatus.FAIL, "<marquee><font color="+"\""+Failredcol+"\"><b> Product Search Result is Failed, Product Name "+ AppValueSearch  +"</b></marquee>" + logger.addScreenCapture(screenshot));
						report.endTest(logger);
						driver.findElement(By.xpath(element.Logout)).click();
						Thread.sleep(3000);
						driver.close();
						 driver.quit();
						continue;
					}
					
					

					String ScoreRecord = driver.findElement(By.xpath(element.ScoreApp)).getText();
					
				//	logger.log(LogStatus.PASS, "Displayed record of product score in dashboard page of Appscript application is: "+ScoreRecord);
					//System.out.println("Score record is:"+ScoreRecord);

					screenshot = util.screenshot(driver, "Verify the product name in dashboard page of AppScript Application");
					
					logger.log(LogStatus.PASS, "Verify the product name in dashboard page of AppScript Application" + logger.addScreenCapture(screenshot));

					WebElement DisplayedRecords = driver.findElement(By.xpath(element.DisplayingApp));
					DisplayedRecords.click();
					
					screenshot = util.screenshot(driver, "Score Displayed in Product Detail Page");

					//Verify the product and other details 
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element.DisplayedAppScore)));
					String DisplayedProductScore = driver.findElement(By.xpath(element.DisplayedAppScore)).getText();
					
					logger.log(LogStatus.PASS, "Displayed record of product score in dashboard page of Appscript application is: "+ScoreRecord  + logger.addScreenCapture(screenshot));
					
					if(ScoreRecord.equals(DisplayedProductScore)){
						System.out.println("The product score is matching in dashboard and details page");
						logger.log(LogStatus.PASS, "The product score is:<b>"+ScoreRecord+" </b> in dashboard page and is matching to the product score in details page with value: <b>" + DisplayedProductScore +"</b>");
					}else{
						System.out.println("The product score is not matching in dashboard and details page");
						logger.log(LogStatus.FAIL, "The product score is:<b> "+ScoreRecord+" </b> in dashboard page and is not matching to the product score in details page with value: <b>" + DisplayedProductScore +"</b>");
					}

					//verify the 4 tabs is present in the product details page
					WebElement DescriptionTab = driver.findElement(By.xpath(element.DescriptionTab));
					if(DescriptionTab.isDisplayed()){
						logger.log(LogStatus.PASS, DescriptionTab.getText()+" Tab is found in details page of appscript");
					}else{
						logger.log(LogStatus.FAIL, DescriptionTab.getText()+" Tab is not found in details page of appscript" );
					}

					WebElement GalleryTab = driver.findElement(By.xpath(element.GallaryTab));
					if(GalleryTab.isDisplayed()){
						logger.log(LogStatus.PASS, "\""+GalleryTab.getText()+ "\""+" Tab is found in details page of appscript");
					}else{
						logger.log(LogStatus.FAIL,GalleryTab.getText()+"Tab is not found in details page of appscript" );
					}

					WebElement RatingsTab = driver.findElement(By.xpath(element.RatingsTab));
					if(RatingsTab.isDisplayed()){
						logger.log(LogStatus.PASS, "\""+RatingsTab.getText()+"\""+" Tab is found in details page of appscript");
					}else{
						logger.log(LogStatus.FAIL,RatingsTab.getText()+"Tab is not found in details page of appscript" );
					}

					WebElement ScoreTab = driver.findElement(By.xpath(element.ScoreTab));
					if(ScoreTab.isDisplayed()){
						logger.log(LogStatus.PASS, ScoreTab.getText()+" Tab is found in details page of appscript");
					}else{
						logger.log(LogStatus.FAIL, ScoreTab.getText()+" Tab is not found in details page of appscript" );
					}

					screenshot = util.screenshot(driver, "Verify the tabs present in product details page of AppScript Application");
					logger.log(LogStatus.PASS, "Verify the tabs present in product details page of AppScript Application" + logger.addScreenCapture(screenshot));

					//click on ratings tab and give the review and ratings
					driver.findElement(By.xpath(element.RatingsTab)).click();
					WebElement RateItButton = driver.findElement(By.xpath(element.RateItButton));
					RateItButton.click();

					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element.StarRating)));
					int rowCount= driver.findElements(By.xpath(element.RatingStar)).size();
					System.out.println(rowCount+"row(s) found");
					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					for(int l=1; l<= rowCount;l++){
						boolean Ratings= driver.findElement(By.xpath("//*[@id='review-rating']/img["+l+"]")).isDisplayed();
						driver.findElement(By.xpath("//*[@id='review-rating']/img["+l+"]")).click();
					}

					String ReviewValue = test.getCellData(xlFilePath, sheet,"Review Value", i);
					WebElement Review = driver.findElement(By.xpath(element.ReviewTextArea));
					Review.sendKeys(ReviewValue);


					screenshot = util.screenshot(driver, "Provide the ratings and review of the product selected in AppScript Application");
					logger.log(LogStatus.PASS, "Provide the ratings and review of the product selected in AppScript Application" + logger.addScreenCapture(screenshot));

					WebElement submitReviewButton = driver.findElement(By.xpath(element.submitReviewButton));
					submitReviewButton.click();

					WebElement SuccessMessage = driver.findElement(By.xpath(element.successMessage)); 
					screenshot = util.screenshot(driver, "Success message of the product selected in AppScript Application");
					logger.log(LogStatus.PASS, "The success message is: "+"\""+SuccessMessage.getText()+"\"");

					WebElement RetreiveReview = driver.findElement(By.xpath(element.RetrieveReviewComments));
					logger.log(LogStatus.PASS, "The Review comment is: "+"\""+RetreiveReview.getText()+"\"");

					driver.findElement(By.xpath(element.Logout)).click();

					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element.UserName)));
					screenshot = util.screenshot(driver, "Back to login page of appscript application");
					logger.log(LogStatus.PASS, "Back to login page of appscript application" + logger.addScreenCapture(screenshot));

					report.endTest(logger);
					driver.close();
					 driver.quit();
				}
				else{
					System.out.println("Execution is not pickeds up !!!!!!! since Flag is not 'Y' ");
				}
				// driver.close();
				// driver.quit();

			}

			return true;

		}  catch (UnhandledAlertException alert) {
			return false;
		} catch (NoSuchElementException e) {
			logger.log(LogStatus.FAIL, "Unable to find Element Exception" + e.getMessage() + logger.addScreenCapture(screenshot));
			return false;
		} catch (NoSuchFrameException e) {
			return false;
		} catch (Error e) {
			return false;
		}

	}

	/********************************************************************************************
	 * @Function_Name : AppscriptValidation
	 * @Description :  Verifying an app in the appscript application
	 * @author : Madhura	
	 * @return boolean
	 ********************************************************************************************/

	public static boolean  AppscriptValidation (ExtentReports report,ExtentTest logger){
		WebDriverWait wait = new WebDriverWait(driver,20);
		boolean Status = false ;
		String col = "BLUE";
		String xlFilePath=System.getProperty("user.dir")+"/TestData.xlsx"; //DOT->current path of Java Project
		String sheet="Appscript";
		int rc = test.getRowCount(xlFilePath, sheet);
		try
		{
			String screenshot = util.screenshot(driver, "Login into Appscript application with valid credentials");
			logger.log(LogStatus.PASS, "Login into Appscript application" + logger.addScreenCapture(screenshot));
			String actualTitle = driver.getTitle();
			String expectedTitle = "AppScript Prescriber | Consumer Store";
			if (expectedTitle.contains(actualTitle)){
				logger.log(LogStatus.PASS, "The title is displayed on the web page:<b> "+driver.getTitle()+"</b>" );
			}       else{
				logger.log(LogStatus.FAIL, "An title is displayed on the web page: <b>"+driver.getTitle()+"</b>");
				Assert.assertTrue(false);
			}
			driver.findElement(By.xpath(element.Login_Button)).click();

			for(int i=1; i<=rc; i++){
				String Falgexecution = test.getCellData(xlFilePath, sheet,"ExecutionFlag", i);
				if(Falgexecution.equalsIgnoreCase("Y")){
					String AppValueSearch = test.getCellData(xlFilePath, sheet,"App Value", i);
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element.SearchMedicine)));
					WebElement SearchMedicine = driver.findElement(By.xpath(element.SearchMedicine));
					SearchMedicine.sendKeys(AppValueSearch);
					screenshot = util.screenshot(driver, "Search a product in Appscript Application");
					logger.log(LogStatus.PASS, "Search a product in Appscript Application" + logger.addScreenCapture(screenshot));
					System.out.println(SearchMedicine.getAttribute("value"));
					logger.log(LogStatus.PASS, "The searched product in dashboard page of Appscript application is: <b>"+SearchMedicine.getAttribute("value")+"</b>");
					driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
					SearchMedicine.sendKeys(Keys.ENTER);
				}else{
					System.out.println("Execution Flag is not set hence not able to procced with the script");
				}
			}

			//Verify the product name in the dashboard page
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element.DisplayingApp)));
			String DisplayingRecords = driver.findElement(By.xpath(element.DisplayingApp)).getText();
			logger.log(LogStatus.PASS,"<marquee><font color="+"\""+col+"\">Displayed record of product name in dashboard page of Appscript application is: "+DisplayingRecords+"</marquee>");
			System.out.println("displaying record is:"+DisplayingRecords);


			String ScoreRecord = driver.findElement(By.xpath(element.ScoreApp)).getText();
			logger.log(LogStatus.PASS, "Displayed record of product score in dashboard page of Appscript application is: "+ScoreRecord);
			System.out.println("Score record is:"+ScoreRecord);

			screenshot = util.screenshot(driver, "Verify the product name in dashboard page of AppScript Application");
			logger.log(LogStatus.PASS, "Verify the product name in dashboard page of AppScript Application" + logger.addScreenCapture(screenshot));

			WebElement DisplayedRecords = driver.findElement(By.xpath(element.DisplayingApp));
			DisplayedRecords.click();

			//Verify the product and other details 
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element.DisplayedAppScore)));
			String DisplayedProductScore = driver.findElement(By.xpath(element.DisplayedAppScore)).getText();
			logger.log(LogStatus.PASS, "Displayed record of product score in dashboard page of Appscript application is: "+ScoreRecord);
			if(ScoreRecord.equals(DisplayedProductScore)){
				System.out.println("The product score is matching in dashboard and details page");
				logger.log(LogStatus.PASS, "The product score is:<b>"+ScoreRecord+" </b> in dashboard page and is matching to the product score in details page with value: <b>" + DisplayedProductScore +"</b>");
			}else{
				System.out.println("The product score is not matching in dashboard and details page");
				logger.log(LogStatus.FAIL, "The product score is:<b> "+ScoreRecord+" </b> in dashboard page and is not matching to the product score in details page with value: <b>" + DisplayedProductScore +"</b>");
			}

			//verify the 4 tabs is present in the product details page
			WebElement DescriptionTab = driver.findElement(By.xpath(element.DescriptionTab));
			if(DescriptionTab.isDisplayed()){
				logger.log(LogStatus.PASS, DescriptionTab.getText()+" Tab is found in details page of appscript");
			}else{
				logger.log(LogStatus.FAIL, DescriptionTab.getText()+" Tab is not found in details page of appscript" );
			}

			WebElement GalleryTab = driver.findElement(By.xpath(element.GallaryTab));
			if(GalleryTab.isDisplayed()){
				logger.log(LogStatus.PASS, "\""+GalleryTab.getText()+ "\""+" Tab is found in details page of appscript");
			}else{
				logger.log(LogStatus.FAIL,GalleryTab.getText()+"Tab is not found in details page of appscript" );
			}

			WebElement RatingsTab = driver.findElement(By.xpath(element.RatingsTab));
			if(RatingsTab.isDisplayed()){
				logger.log(LogStatus.PASS, "\""+RatingsTab.getText()+"\""+" Tab is found in details page of appscript");
			}else{
				logger.log(LogStatus.FAIL,RatingsTab.getText()+"Tab is not found in details page of appscript" );
			}

			WebElement ScoreTab = driver.findElement(By.xpath(element.ScoreTab));
			if(ScoreTab.isDisplayed()){
				logger.log(LogStatus.PASS, ScoreTab.getText()+" Tab is found in details page of appscript");
			}else{
				logger.log(LogStatus.FAIL, ScoreTab.getText()+" Tab is not found in details page of appscript" );
			}

			screenshot = util.screenshot(driver, "Verify the tabs present in product details page of AppScript Application");
			logger.log(LogStatus.PASS, "Verify the tabs present in product details page of AppScript Application" + logger.addScreenCapture(screenshot));

			//click on ratings tab and give the review and ratings
			driver.findElement(By.xpath(element.RatingsTab)).click();
			WebElement RateItButton = driver.findElement(By.xpath(element.RateItButton));
			RateItButton.click();

			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element.StarRating)));
			int rowCount= driver.findElements(By.xpath(element.RatingStar)).size();
			System.out.println(rowCount+"row(s) found");
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			for(int i=1; i<= rowCount;i++){
				boolean Ratings= driver.findElement(By.xpath("//*[@id='review-rating']/img["+i+"]")).isDisplayed();
				driver.findElement(By.xpath("//*[@id='review-rating']/img["+i+"]")).click();
			}

			WebElement Review = driver.findElement(By.xpath(element.ReviewTextArea));
			Review.sendKeys("Good app to use...!!!!");

			screenshot = util.screenshot(driver, "Provide the ratings and review of the product selected in AppScript Application");
			logger.log(LogStatus.PASS, "Provide the ratings and review of the product selected in AppScript Application" + logger.addScreenCapture(screenshot));

			WebElement submitReviewButton = driver.findElement(By.xpath(element.submitReviewButton));
			submitReviewButton.click();

			WebElement SuccessMessage = driver.findElement(By.xpath(element.successMessage)); 
			logger.log(LogStatus.PASS, "The success message is: <b>"+SuccessMessage.getText() +"</b>");

			WebElement RetreiveReview = driver.findElement(By.xpath(element.RetrieveReviewComments));
			logger.log(LogStatus.PASS, "The Review comment is: "+"\""+RetreiveReview.getText()+"\"");

			screenshot = util.screenshot(driver, "Success message of the product selected in AppScript Application");
			logger.log(LogStatus.PASS, "The success message is: "+"\""+SuccessMessage.getText()+"\"");

			driver.findElement(By.xpath(element.Logout)).click();

			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(element.UserName)));
			driver.findElement(By.xpath(element.UserName)).click();
			screenshot = util.screenshot(driver, "Back to login page of appscript application");
			logger.log(LogStatus.PASS, "Back to login page of appscript application" + logger.addScreenCapture(screenshot));

			return true;

		}
		catch(Exception e){
		}
		return false;
	}





public static  String initiatedriver(String URLvalue){
	
	try {

	//	driver = UtilLib.getDriver();
		driver.manage().window().maximize();
	    driver.manage().deleteAllCookies();
	    driver.get(URLvalue);
	}
	
	catch (Exception e) {
		logger.log(LogStatus.FAIL, "Unable to Launch Browser" + logger.addScreenCapture(screenshot));
	}
	return "HI";
 }


}  // class end. 
