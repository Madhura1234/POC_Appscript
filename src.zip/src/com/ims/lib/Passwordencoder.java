package com.ims.lib;

import org.apache.commons.codec.binary.Base64;

public class Passwordencoder {
	public static void main(String args[]) {
	//	String a = "*******";
		String a = "jhh";
		byte[] encodedBytes = Base64.encodeBase64(a.getBytes());
		 System.out.println("encodedBytes "+ new String(encodedBytes));

		byte[] decodedBytes = Base64.decodeBase64(encodedBytes);
		System.out.println("decodedBytes "+ new String(decodedBytes));
	}
}

//
