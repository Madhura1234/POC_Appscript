package com.ims.lib;

import java.io.IOException;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.thoughtworks.selenium.webdriven.commands.WaitForPageToLoad;

public class ApplicationUtility {
	public static UtilLib util = new UtilLib();
	public static ObjectDefinitionLibrary element = new ObjectDefinitionLibrary();
	private static WebDriver driver;

	public ApplicationUtility(WebDriver driver) {
		super();
		this.driver = driver;
	}

	/******************************************************************************************** 
	 * @throws InterruptedException 
	 * @Function_Name : DNA_Login
	 * @Description : Initiate Browser and navigate to the URL with valid credentials
	 ********************************************************************************************/
	public static  void DNA_Login() throws IOException, InterruptedException{
		try {

			driver = UtilLib.getDriver();
			driver.manage().deleteAllCookies();

			String UrlLaunch = util.getPropertiesValue("URL");
			String UN = util.getPropertiesValue("User_Name");
			String Password_property = util.getPropertiesValue("Password");

			driver.get(UrlLaunch);
			System.out.println(UrlLaunch);

			driver.findElement(By.xpath(element.UserName)).clear();
			driver.findElement(By.xpath(element.UserName)).sendKeys(util.getPropertiesValue("User_Name"));

			byte[] decodedBytes = Base64.decodeBase64(Password_property);
			driver.findElement(By.xpath(element.Password)).sendKeys(new String(decodedBytes));

			driver.findElement(By.xpath(element.Login_Button)).click();

		} 

		catch (Error e) {
			e.printStackTrace();
			e.getMessage();

		}
	}
	/********************************************************************************************
	 * @Function_Name : AppNavigation_CSUsers
	 * @Description :  To Check the application navigation for CS Users
	 ********************************************************************************************/
	public static boolean  Validation_CSUser(){
		WebDriverWait wait = new WebDriverWait(driver,80);
		boolean Status = false ;
		try
		{
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element.ClientLoadedData)));
			
			//Click on 'Select' button
			driver.findElement(By.xpath(element.QuatersButton)).click();
			
			//click on the state button for which the Dollar value is present
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element.StateTable)));
			WebElement Statetable = driver.findElement(By.xpath(element.CompleteStatetable));
			List<WebElement> allrows = Statetable.findElements(By.tagName("tr"));
			List<WebElement> allcols = Statetable.findElements(By.tagName("td"));
			System.out.println("Number of rows in the table "+allrows.size());
			System.out.println("Number of columns in the table "+allcols.size());

			for(WebElement row: allrows){
				List<WebElement> Cells = row.findElements(By.tagName("td"));
				for(WebElement Cell:Cells){
					System.out.println(Cell.getText());   
					if (Cell.getText().contains("California"))
						Cell.click();
				}
			}

			
			//Click on the Verify Button of any Program for which Data is available
			Thread.sleep(10000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element.ForReviewTab)));
			driver.findElement(By.xpath(element.VerifyButton)).click();
	
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='dmgt']/tbody/tr[1]/td[1]")));
			
			boolean RejectButton = driver.findElement(By.xpath(element.RejectButtonStatePage)).isDisplayed();
			if(RejectButton==true){	
				System.out.println("Reject button is present in the page");
			}else{
				System.out.println("Reject button is not present in the page");
			}
			
			boolean ApproveButton = driver.findElement(By.xpath(element.ApproveButtonStatePage)).isDisplayed();
			if(ApproveButton==true){	
				System.out.println("Approve button is present in the page");
			}else{
				System.out.println("Approve button is not present in the page");
			}
			driver.findElement(By.xpath(element.StateBackButton)).click();
			
			//Click on the Validation Button of any Program for which Data is available
			Thread.sleep(10000);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element.ValidateButton)));
			driver.findElement(By.xpath(element.ValidateButton)).click();
		
			//Verify the tabs present in validation page
			UtilLib.waitForPageLoad(driver);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element.QuantityTab)));
			
			boolean quantityTab = driver.findElement(By.xpath(element.QuantityTab)).isDisplayed();
			String QuantityTabValue = driver.findElement(By.xpath(element.QuantityTab)).getText();
			if(quantityTab==true){
				System.out.println("The tab that is present in validation page is:"+QuantityTabValue);
			}else{
				System.out.println("The tab that is present in validation page is:"+QuantityTabValue+"======");
			}
			
			
			boolean Tab340BValidation = driver.findElement(By.xpath(element.Tab340B)).isDisplayed();
			String Tab340BValue = driver.findElement(By.xpath(element.Tab340B)).getText();
			if(Tab340BValidation==true){
				System.out.println("The tab that is present in validation page is:"+Tab340BValue);
			}else{
				System.out.println("The tab that is present in validation page is:"+Tab340BValue+"======");
			}
			
			boolean RebillsTab = driver.findElement(By.xpath(element.RebillsTab)).isDisplayed();
			String RebillsTabValue = driver.findElement(By.xpath(element.RebillsTab)).getText();
			if(RebillsTab==true){
				System.out.println("The tab that is present in validation page is:"+RebillsTabValue);
			}else{
				System.out.println("The tab that is present in validation page is:"+RebillsTabValue+"======");
			}
			
			

			
			
		}catch(Exception e ){
			e.printStackTrace();
			e.getMessage();
		}
		return false;
	}
}
