package com.ims.lib;

public class ObjectDefinitionLibrary {
	public String UserName = "//*[@id='dnalogin']/div/div[1]/div[3]/input";
	public String Password = "//*[@id='password-field']";
	public String Login_Button = "//*[@id='dnalogin']/div/div[1]/div[7]/input";
	public String ClientLoadedData = "//*[@id='q2']/div/div/div[2]/div/div[3]/div[1]/h2/span[1]";
	public String QuatersButton ="//div[1]/footer/div/div/button[2]";
	public String StateTable = "//div[@class='invoiceLeftPan']/table/tbody/tr";
	public String CompleteStatetable = "//div[@class='invoiceLeftPan']/table/tbody";
	public String ForReviewTab = "//*[@id='myTab']/li[1]/a";
	public String VerifyButton = "//div[1]/div/div[3]/div[2]/div[1]/div/div[2]/div[1]/div[1]/div[2]/div[9]/button";
	public String StateBackButton = "//nav/div/div[1]/a/p";
	public String RejectButtonStatePage = "//div/div/a/button";
	public String ApproveButtonStatePage = "//body/footer/div/div/button";
	public String ValidateButton = "//div[1]/div/div[3]/div[2]/div[1]/div/div[2]/div[1]/div[1]/a/div/div[1]/div";
	public String QuantityTab = "//*[@id='navbar']/ul/li[2]/div/a/div/div[1]";
	public String Tab340B = "//*[@id='navbar']/ul/li[3]/div/a/div/div[1]";
	public String RebillsTab = "//*[@id='navbar']/ul/li[3]/div/a/div/div[1]";
	
	public String QuaterValue = "//*[@id='quarterContent']/div[1]/div/div[2]/p[1]";
	
}
