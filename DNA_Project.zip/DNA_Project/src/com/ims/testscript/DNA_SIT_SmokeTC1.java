package com.ims.testscript;


import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.ims.lib.ApplicationUtility;

public class DNA_SIT_SmokeTC1 {
//	ExtentReports report  = new ExtentReports(System.getProperty("user.dir")+ "/Reports/Extentreport.html",true);
//	ExtentTest logger;
//	
	@BeforeClass
	public void initiateBrowser() throws Exception{
		ApplicationUtility.DNA_Login();
	}
	
	@Test
	public void checkApplication(){
		ApplicationUtility.Validation_CSUser();
	}
	
	/*@AfterClass
	public void teardown(){
		report.flush();
	}*/
	
}
