package com.ims.testscript;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;



public class Mainmethod {

	public static void main(String[] args) {
		//try{
			// TODO Auto-generated method stub
//			FirefoxDriver driver = new FirefoxDriver();
			File pathToBinary = new File("C:\\Users\\Madhura.G\\AppData\\Local\\Mozilla Firefox\\firefox.exe");
			FirefoxBinary ffBinary = new FirefoxBinary(pathToBinary);
			FirefoxProfile firefoxProfile = new FirefoxProfile();
			FirefoxDriver _driver = new FirefoxDriver(ffBinary,firefoxProfile);
//		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"/chromedriver.exe");
//			WebDriver driver = new ChromeDriver();s
			_driver.get("http://www.google.com");
		System.out.println("##############");
		}
	/*	catch(Exception e){
			e.printStackTrace();
		}*/
	//}
}
